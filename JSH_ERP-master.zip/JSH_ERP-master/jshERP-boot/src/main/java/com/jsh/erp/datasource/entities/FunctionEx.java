package com.jsh.erp.datasource.entities;

public class FunctionEx extends Function {

    private String parentName;

    public String getParentName() {
        return parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }
}